<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Pesan Anonim</h1>
    <p>Nama : {{$details['nama']}}</p>
    <p>Mail : {{$details['email']}}</p>
    <p>Phone : {{$details['phone']}}</p>
    <p>Pesan : {{$details['msg']}}</p>
</body>
</html>