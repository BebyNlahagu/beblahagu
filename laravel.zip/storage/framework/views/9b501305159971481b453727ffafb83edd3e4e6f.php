<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Pesan Anonim</h1>
    <p>Nama : <?php echo e($details('name')); ?></p>
    <p>Email : <?php echo e($details('email')); ?></p>
    <p>Phone : <?php echo e($details('phone')); ?></p>
    <p>Pesan : <?php echo e($details('msg')); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\fortofolio\portfolio\resources\views/Email/gmail.blade.php ENDPATH**/ ?>